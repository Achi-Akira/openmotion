> See [source and execution notes](../PROVENANCE.md).

# Game review rubric and inherited website checklist

The complete inherited checklist below is retained for provenance and applicable ancillary landing pages. For a game, items 3 (website palette bans), 5b (hosted absolute metadata), 7 (SSR), 9 (bespoke CTA instead of shared controls), 9c (legacy branding) and 9d–9f (scroll-scrub website defaults) apply **only** when that separate website surface exists; record N/A otherwise. They never require adding a scrolling movie to a game or bypassing the Studio design system. Authored game palettes follow the approved STYLE FORMULA. For Studio controls use shared OpenDesign components. Actual browser visual and gameplay review remains required; a mechanical pass is not visual acceptance.

Game-specific completion checks: six exports; deterministic authoritative rules; bounded validated inputs; no client-trusted damage; relative assets load; clip transitions; reachable win/loss; restart; co-op starts with one player by default; touch joystick/tap and keyboard/mouse (including release/cancel and focus loss); disconnect/rejoin and late join; performance on the weakest target; sound-disabled play; `openmotion_game_validate`; required server-owned `openmotion_game_playtest` with meaningful 1–4 client scripts and inspection of errors, failed requests, screenshots, joined/player-count metrics. Validate real HP/down/revive, solo five-second respawn, dash/nova cooldowns, wave countdown, spawn order and restart. Before publication, require `design/plan.md`, `design/assets.csv` and `design/verification.md`: experience formula, numeric metrics/thresholds, wave/difficulty plan, sources/licenses/costs, actual inputs/results and known gaps. Run `openmotion_game_simulate` for both routes: reference must win, idle must lose terminally; timeout is not a loss. Check `window.__omGame` snapshot/action hooks and `?debug` metrics, then inspect every playtest assertion (player count, phase, net displacement above threshold, no horizontal overflow at 390×844). Missing design files produce non-blocking reminders but still require the Agent to complete the artifacts. Before publication, verify concise title/description/controls, zh-CN i18n and a real project-relative cover set with openmotion_game_update_meta. **Require `openmotion_game_capture_cover` for game-only cover capture. Never operate, attach to or screenshot the user's visible browser, existing profile or desktop. Reject covers containing browser chrome or unrelated windows; metadata enforces at least 960×540 and 16:9 ±5%. A missing headless browser/loopback permission must be reported; do not substitute the user's Chrome.** Review advisory missing-cover/starter-similarity warnings; do not add filler lines to clear them. Report non-blocking publication metadata warnings. Publication requires authorization and stays local.

# review-rubric — Phase 5 mechanical gate

§A runs BEFORE deploy and is a completion gate, not a suggestion. Most items
are verified by grep/code inspection. **Item 9f is the hard machine gate for the
animated-website default: a website that ships without the scroll-scrub component
+ scene media (and without an explicit `non-animated` choice in the brief) FAILS, no matter
how polished the rest is** — this is the single most common miss, so run 9f every
time. For the animated website, item 9e adds its interactive runtime checks in
local preview before the final deploy. There is no post-deploy visual/screenshot
review — this mechanical gate is the only verification.

## §A. Mechanical gate (pre-deploy, code-level)

Check each item; fix every hit before deploying.

1. **Placeholders** — zero `<...>`-style tokens (e.g. `<brand name>`, `<product>`),
   `lorem`, `REMOVE_THIS`, `blank-app-v1`, or empty `src=""`. Grep for the
   literal markers: `grep -rniE 'lorem ipsum|REMOVE_THIS|blank-app-v1' ./`,
   and scan for any remaining `<...>` placeholder tokens in quoted strings.
2. **Em-dash ban** — `grep -rn "—\|–" ./` over user-visible strings returns
   nothing (code comments exempt).
3. **Banned default palette** — none of the banned palette families from
   `design-recipe.md` §2 appear in `styles.css`/tokens: beige/brass/espresso
   hexes, graphite/near-black + orange/amber/ember accent, near-black + neon
   cyan/blue/green accent, AI purple/violet glow, or the palette family of your
   previous build in this chat. Overridable ONLY by the user's explicit brand
   colors, justified in the design brief.
4. **Eyebrow ration** — count **eyebrow-position section labels only**. An
   eyebrow is a small uppercase/mono kicker sitting DIRECTLY above the
   section's display headline in the same column; nothing else counts. Must
   be ≤ ceil(sectionCount / 3). Uppercase mono in non-eyebrow roles (spec
   strips, table/metric captions, rail labels, footer column heads) is
   exempt — especially when the reference boards show them. Grep for
   `uppercase tracking` to find candidates, then classify by position.
5. **Asset kit complete + referenced** — every file downloaded into
   `assets/` is actually referenced by a route/component; the hero
   references a real generated asset (no picsum/stock/CSS-gradient-only hero);
   the icon slots use the generated icon set (or the documented library
   fallback), and no kit item from `asset-system.md`'s "always" list is
   silently missing.
5b. **Head kit complete** — the full favicon/meta set from `asset-system.md`
   §7 is present and wired: favicon (ico/svg + png sizes), apple-touch-icon,
   192/512 + maskable icons with a `site.webmanifest`, `theme-color`, and the
   full OG + twitter card block with absolute image URLs. An empty `<head>`
   or the scaffold's default favicon is a gate failure.
6. **`h-screen`** — zero occurrences; use `h-dvh` / `min-h-dvh`.
7. **SSR safety** — no `window` / `document` / `localStorage` / `navigator` at
   module top level or in render; every `[C]`/`[W]` component behind a mounted
   gate; `[W]` additionally `React.lazy`.
8. **Reduced motion** — every animation source (`motion/react`, GSAP, registry
   components) paired with a `prefers-reduced-motion` guard or static fallback.
9. **CTA integrity + bespoke chrome** — one label per intent page-wide (no "Get
   in touch" + "Contact us"); no CTA label longer than ~3 words for primaries;
   AND no shared site-wide button style: grep for a repeated CTA class string /
   `Button` utility component reused across sections — every CTA per the brief's
   inventory has its own component with its own interaction identity.
9b. **Screenshot-safe reveals** — flag any `opacity: 0` / `opacity-0` **whose
   removal depends on a viewport/scroll trigger** (`whileInView`,
   IntersectionObserver entry, ScrollTrigger-gated fade-ins). Hover-state
   decorations at opacity-0 are fine. Nothing may sit invisible waiting for a
   viewport trigger; animate from visible states (y-offset/blur) or fire on
   mount. Video elements need a `poster` (or a rendered first frame) so
   headless shots never show a black box. A full-page headless screenshot
   must show every section.
9c. **No Higgsfield branding on `type: "website"` builds** —
   `grep -rin "higgsfield\|quanta" ./` returns no user-visible strings,
   no Quanta imports, no q-prefixed tokens, no "Powered by / Built on" badge,
   no Higgsfield marks in page chrome. fnf/auth strings in server/service
   code are fine — that's the functional contract, not branding. On
   `type: "app"` builds this check inverts for the design system: Quanta
   imports and q- tokens are REQUIRED there and "Sign in with Higgsfield" is
   part of the product — only gratuitous "Powered by / Built on Higgsfield"
   marketing badges remain forbidden.
9d. **Anti-convergence ledger honored** — the brief lists the previous
   build's six identity axes (palette family, type pairing, hero
   architecture, Tier-1 technique, CTA garments, corner language) and this
   build differs on ≥4; the rationed garments (drawing underline, hover
   flood-fill, framed block) appear at most once page-wide combined. On the
   `non-animated` path the Tier-1 technique carries a `wow-catalog.md` ID and is
   interactive (not a passive loop); on the default `animated-website` path the
   Tier-1 technique IS the scroll-scrub animated website (enforced by 9f) — a
   generic wow-catalog ID does NOT satisfy the default path.
9e. **Animated website — A4 seam-locked scroll scrub (every website by default;
   skip only if the user explicitly opted out)** — verify every media segment
   has a first-frame poster extracted from the
   exact deployed clip; chapter copy is server-rendered in semantic document
   flow (not hidden until a viewport callback); `prefers-reduced-motion`
   performs no video fetch and shows the complete static story; desktop and
   lighter mobile encodes are wired; connector/leg handoffs use the neighboring
   rendered clips' ACTUAL boundary frames; camera velocity does not reverse
   accidentally; initialization runs only in an effect; and teardown aborts
   fetches, removes listeners/video nodes, cancels RAF, and revokes Blob URLs.
   Scrub videos directly from seekable MP4/Blob URLs, ensure CSP `media-src`
   permits `blob:`, and ensure no second ScrollTrigger timeline drives the same
   media. Inspect each seam immediately before/after in both scroll directions
   and test source swapping, a fast mobile flick, and unmount/remount in local
   preview before final deploy.
9f. **Animation mode gate (machine-verifiable — HARD, every website).** This is
   the completion gate for the animated-website default; a site that passes every
   other check but this one is NOT done. Steps:
   1. `grep -n "^Animation mode:" design/design-brief.md` — there MUST be exactly
      one such line. Zero matches → FAIL (the brief never declared the state).
   2. If the value is **`animated-website`**, ALL of these must hold, or FAIL:
      - the scroll-scrub component exists —
        `ls ./components/scroll-scrub/scroll-scrub.tsx` succeeds — and is
        actually imported/rendered by a route (grep for its import);
      - real film shipped — at least ONE clip (`single-shot` ships exactly
        one; a `multi-leg` journey ships one per leg) under
        `assets/assets/**/*.mp4` (the seam-locked chain), each with a
        first-frame poster (item 9e);
      - the brief carries the journey block (Journey scenes + Camera
        architecture A/B) written in Phase 0.
      A website on this path with no scroll-scrub component or no scene MP4s is
      the failure mode this gate exists to catch — do NOT deploy it; go build the
      camera journey.
   3. If the value is **`non-animated`**, the line MUST record the user's choice
      (an intake pick or a verbatim request). No scroll-scrub artifacts are
      required; instead confirm the site clears the `wow-maker.md` craft floor and
      any chosen `wow-catalog.md` technique is actually built (9d). A
      `non-animated` with no recorded user choice → FAIL (treat as
      `animated-website` and go back to step 2).
10. **Section plan honored** — the built page matches `design/design-brief.md`'s
    section plan (families, order, no consecutive family repeats). If the plan
    changed during the build, the brief was updated to match.
11. **Copy self-audit** — every visible string re-read; nothing grammatically
    broken, referent-unclear, filler-verb ("Elevate", "Seamless"…), or fake-precise
    (`92%`, `4.1×` without a source).

## Playable-ad addendum

For a **Format: playable ad** brief, score each line 0 (missing), 1 (partial) or 2 (meets the [playable-ad recipe](game-playable-ad.md)) and record the scores with evidence in `design/verification.md`. Ship only with no 0 and a total of at least 10 of 12; name every 1 in the final message.

| Line | 2 means |
|---|---|
| First-frame play | Scene and player object drawn on the first frame, no title card; the first touch anywhere starts play and scores within 1 s |
| Tutorial | Animated hand on the exact first-move target with one short line; hides on input, returns after the hint delay |
| Level arc | 3–8 levels: obvious level-1 win, a near-fail level (pilot `maxDanger` 0.6–0.9), a twist; reference wins and idle loses terminally in `openmotion_game_simulate` |
| End card and CTA | Win and fail cards both reached in playtest; CTA (primary) and Play again (secondary); CTA tap logs `cta_click` through `openStore()`, Play again never does |
| Single file | Inlined `index.html` regenerated from the sources; zero requests; no storage, dialogs or SDK stubs; size reported |
| Polish | No overlapping HUD numbers or popups at 390×844; corners free; feedback on every input; three languages fit |

## Optional post-publication trailer acceptance

- Offer a trailer after publishing; run `openmotion_game_trailer` only when requested. Use its server-owned headless recording, never the user's visible browser/profile/desktop.
- Inspect three actual gameplay clips, title/cover, localized title, short captions and Play now/controls in the editable native project. Generic recorded inputs are not a substitute for the required reference-win and idle-loss simulations.
- Report ready only when the existing export pipeline finishes and videoUrl is available. Verify the final MP4 separately from composition JSON or a created project. The output is silent.
- Report missing Chrome/ffmpeg/export runtime, interrupted jobs, errors and retained clips/projectId honestly. No dependency download, paid generation, internet hosting or human video acceptance is implied.

## Multiplayer entry checks

Apply the [automatic-join acceptance checklist](../SKILL.md#mandatory-multiplayer-entry-acceptance).
