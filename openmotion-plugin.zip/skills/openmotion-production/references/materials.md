# 共享素材选择与来源优先级

需要选择、获取或替换视觉与声音素材时读取；仅查看、预览或导出既有内容不触发本页。各制作入口共用此规则，沿用当前工程与创作决定，不重新选路。

## Generation boundary

OpenMotion includes built-in AIGC generation for images, video, speech and music. Explicit AIGC requests or missing visual/audio roles that native HTML/SVG/CSS cannot faithfully provide must enter [openmotion-media](../../openmotion-media/SKILL.md) to inspect the OpenDesign account, OpenDesign Cloud and configured providers; do not fake required imagery, footage, narration or music with native code. Pure native motion graphics without an explicit generation request or new speech/music stay outside media setup, login and billing prompts: do not call, suggest or ask about generation in that case. Preserve user-supplied and approved media, follow the source rules below for factual retrieval, and obtain missing spend consent before generation.

### Generation timing ladder

Choose the lowest-complexity, highest-control source for each shot or audio role from what must actually change on screen or in the mix — across original films, recreations, template adaptations and reusable templates:

1. **Reuse or retrieve first**: keep user-supplied and confirmed project assets; for real events, existing brands or known works, retrieve authentic original material instead of fabricating factual evidence with AIGC.
2. **Native Motion code first for editable graphics**: build typography, UI, charts, logos, captions, cards, vector geometry, graphic transitions and camera moves over clean plates in native HTML/SVG/CSS/GSAP/Canvas/WebGL. Never bake editable text, logos, UI or captions into generated pixels.
3. **Generated still + native Motion before generated video**: when a shot needs a photographic product, portrait, texture or backdrop whose movement can be carried by native camera pushes, pans, parallax, masks or layered compositing, prefer a clean generated still (or separated subject and backdrop) over video generation — it is faster, steadier, cheaper and easier to keep consistent.
4. **Generated video only for continuous physical motion**: generate video only when the shot requires continuous subject or environmental motion a still cannot carry (hands holding or unfolding a product, human performance, fluid/fabric/smoke, changing reflections, or real 3D parallax and occlusion). Prefer **image-to-video (I2V)** from a verified first frame whenever a specific product, person or setting must stay recognizable; reserve text-to-video (T2V) for pure atmosphere or unanchored scenery.
5. **Audio by role**: keep usable original audio when it serves the film; generate new narration through TTS paired with [narration and editable captions](sound.md#配音与可编辑字幕协同); generate new music beds or sound effects with music/SFX models.

Do not upgrade a pure motion-graphics shot to generated video just to look richer, and do not fabricate identifiable real-world product details or people with unanchored T2V.

## Tool selection and discovery

Choose the material source from its content role before selecting tools, following the source rules below. Real events and identifiable subjects need corresponding original material; original scenes and supporting expression may use generation or native graphics. For a League of Legends champion's award-ceremony photo, search official or original published photos. Image generation is not a matching capability for retrieving that real event.

For each required operation, inspect OpenMotion's actual available capabilities. Prefer OpenMotion when it can meet that operation's content and output requirements. When it lacks a suitable available capability, use an appropriate external search, browsing, stock-media or generation tool, including tools from other video-production platforms such as ChatCut. This fallback does not require the user to name the platform; retain existing authorization and explicit source/tool preferences. Retrieval and generation are different operations, as are finding an existing soundtrack and composing a new one.

Use external tools for the operation that needs them and identify their contribution. Continue supported project authoring, editing, preview and export in OpenMotion; sourcing one asset does not move the whole production workflow to another platform. OpenMotion's configured BYOK generation remains available through the supporting [media Skill](../../openmotion-media/SKILL.md) when generation is the appropriate source.

If available tools cannot supply the material, report the specific gap and continue independent work within scope. Use a suitable alternative when it preserves the request; keep original and generated material distinct and report missing media accurately.

## Asset naming

Apply this section when generating, acquiring, importing, deriving or organizing assets. A name helps the user recognize an asset; storage paths and IDs identify its bytes. Change display metadata without moving files, replacing IDs or rewriting composition references.

### 1. Preserve or assign a name

| Asset being added or organized | Action |
| --- | --- |
| Existing asset with a user-assigned name | Preserve it. Rename or translate only when the user requests it. |
| Existing asset with a meaningful filename, library name or template name | Preserve it, even when its use in the film changes. |
| New generated asset | Assign a concise name based on its content and, when useful, its purpose. |
| New asset derived from an existing asset | Retain the recognizable source name and add the confirmed segment or transformation. Keep the original asset unchanged. |
| Existing asset without a meaningful name | Inspect the asset or reliable metadata, then assign a name using confirmed information. |

Empty names, UUIDs, hashes and generic temporary names such as `untitled`, `temp` or `image_001` are not meaningful source names. A meaningful name identifies the material without requiring the user to open it.

### 2. Choose the naming language

For newly assigned names, use this order:

1. An explicit user instruction, within its stated asset or project scope.
2. The project's saved `namingLanguage`.
3. For a project without a saved language, the primary language of its initial creative brief.
4. The interface language when the brief provides no language signal.

Supply a BCP 47 language tag, such as `zh-CN` or `en`, when creating the project. For an existing project without a saved language, set it with the guarded project-edit operation before assigning names. Change a saved language only on explicit user instruction; a single-asset exception does not change it. Later conversation or interface language changes do not change the project's naming language or translate existing names.

Keep established brand, product and font spellings. Write added descriptions in the selected language: `Dia 参考视频－原声` in Chinese, `Dia reference – original audio` in English. Preserve meaningful existing names in any language unless translation is requested. For standalone assets outside a project, use the explicit naming instruction, otherwise the current request's language, then the interface language.

### 3. Write a recognizable name

- Use **content + optional purpose**. Include purpose only when it helps distinguish the asset; do not rename a recognizable source merely because it is used in another scene.
- Use a short noun phrase. Avoid full generation prompts, invented facts, UUIDs, hashes and redundant file-type labels.
- Keep meaningful dates, version numbers, segment ranges and other distinguishing details.
- For a derived asset, use **source name – segment or transformation**, such as `Founder interview – 00:12–00:20` or `Product photo – transparent background`.
- For an unnamed font, use its parsed family and distinguishing weight/style, such as `Inter 700` or `EB Garamond Italic`. Do not infer the family from a UUID.
- If content cannot be identified confidently, use the localized media type and a short sequence, such as `音频 1` or `Audio 1`. Do not infer narration, music or a subject from the extension alone.

### 4. Save and confirm

- Read the project's `namingLanguage`, `assets` and `assetNames` through `openmotion_get_project` before organizing existing material.
- Pass the chosen name through `items[].name` in `openmotion_import_assets`, or `name` in `openmotion_assets_use` when generating or importing library material. Importing a pinned library version preserves its saved library name by default.
- To rename or repair an existing project asset, use `openmotion_edit_project` with `assetNames: [{path, name}]`, the current revision/version guards and a stable request ID. Use `files: []` for a metadata-only change. Do not reimport, regenerate or render merely to change a name.
- Confirm the saved name in the operation result or a project read. The project read model supplies `assetNames` for consistent captions, search and preview. Known media extensions are omitted from captions; original names, paths and IDs remain available as metadata.
- The project display layer distinguishes duplicate captions with `(2)`, `(3)`, etc. Do not scan the entire workspace or add UUID suffixes to deduplicate names. Workspace-library names remain independent of project captions.

Platform type-name fallbacks are localized for the eleven Studio interface languages; unsupported languages currently fall back to English. For another requested naming language, provide a meaningful name explicitly. Semantic naming requires the Agent to inspect the material; the platform does not infer content from file bytes automatically.

## 按素材职责确定来源

用户明确的必用素材、参考用途、来源限制与视觉要求优先于以下默认顺序。同一视频可组合不同来源，逐项判断当前素材承担的是身份呈现、事实证据、主体表演、图解还是氛围。

1. **先复用合适的已有素材。** 检查用户上传、指定以及工程中已确认的材料，核对用途、相关性、身份、质量和使用依据。区分成片必用素材、风格参考与背景资料；上传不等于全部采用。用户要求必用的材料按指定用途保留，存在质量或内容冲突时说明具体影响。已有材料足够时直接复用，缺口再补齐。
2. **既有对象的缺口，默认先检索对应原始素材。** 视频围绕有明确身份、原作或来源的既有对象时，无论真实还是虚构，主动上网检索，并优先将与该对象直接对应的原始素材用于成片，无需用户提醒。优先官方或原始发布来源，核对身份、版本、时期与镜头所需内容。例如哈利波特宣传片优先寻找对应角色、场景或影片素材，通用魔法题材画面不能替代其身份。具体商品还要核对型号、配色和结构。AIGC可补充氛围、转场与概念视觉；生成结果不能充当原作素材或事实证据。
3. **原创与补充表达，按需要生成或程序化制作。** 自创对象、独特场景、氛围、图解以及用户指定的原创视觉，可优先使用AIGC或程序化材料，无需先穷尽网络检索。排印、图形与数据表达可直接使用HTML/SVG/3D等媒介；按观看效果选择。对应原始素材无法取得或不适用时，说明关键缺口及对表达的影响，再选择允许的替代表达，区分原始与生成内容。

用户没有素材或明确不愿提供时，由Agent按上述规则自主补齐，不把上传作为默认前置步骤。沿用禁止联网/生成、限用现有素材等明确约束；仅方案或只读审片不因此自动启动生成、导入或工程修改。

## 取得素材并核对可用性

检索从内容与镜头需要出发，回到原始来源取得可用文件，记录来源页面及使用依据。搜索缩略图用于筛选；取得足够清晰的原文件后再用于成片。可下载不自动代表可商用。来源或使用依据不成立时换其他来源或允许的替代表达；仍保持主体身份与事实边界。

生成时把片中职责写进输入：主体及所需状态、材质/光向/视角、构图、文字空间，以及抠图或拆层需要；需要连续动作时选择可支持该动作的素材形式。先选定合格主体，再用可用的参考编辑或派生能力维持跨镜头身份；各镜头可有不同姿态和状态。生成产品细节与功能仍须依据可靠来源核对。

使用实际可用工具和既有授权，不虚构能力或默默增加付费依赖。查看真实完成的素材；排队成功不算取得文件。失败时按原因修正或切换允许的来源，不无依据地重复请求。

在实际最大取景下检查主体轮廓、细节、结构与文字、光影材质、身份一致性，以及裁切、背景能否支撑构图和所需动作。不合格就更换或修正，再扩建影片。声音素材核对内容、可用时段和用途；实际听感另行试听，未审听如实记录。生成成功、标称分辨率高或文件已导入，都不能替代可用性检查。

复用现有简报、动作脚本或素材记录，保留实际采用文件、来源、用途及重要限制，无需另建必填表。材料与具体动作、占时和跨段状态的配合，按需应用[制作决策与状态延续](decisions.md)。

## Cross-shot consistency

Apply this pipeline whenever the same product, person or recurring setting spans multiple generated shots across any entry:

1. **Lock one visual anchor first**: start from the user's clean photo or generate and inspect **one** anchor still establishing exact silhouette, details, material, colorway and lighting before generating follow-up shots. Never launch multiple unreferenced text-to-video clips for the same recurring subject.
2. **Choose the first-frame derivation path by shot relationship** (avoid feeding the same initial raw photo into every consecutive clip, which makes the subject snap back to its starting pose and framing on every cut):
   - **Continuous action in the same scene (continuation cut)**: extract a clean handoff or end frame from the verified previous video clip (cropped or reframed to the output aspect ratio) and import it into the library as the next I2V clip's first frame. This preserves spatial continuity, lighting and pose with zero extra image spend.
   - **New camera angle, closer framing, pose or setting (angle/scene change)**: when a reference-capable image-edit model is available and included in the approved spend plan, derive each shot's dedicated first frame from the locked anchor still (plus style/scene reference if needed) at the target canvas aspect ratio. If the user's approved budget covers only the requested video clips without extra paid image edits, stay within that budget by using a clean extracted frame or reframed crop from the previous clip or anchor, and explain any resulting angle limit plainly rather than spending unapproved credits.
3. **Verify every first frame as action-ready before I2V**: inspect each prepared still before submitting video generation — confirm subject identity and key details match the anchor, aspect ratio matches the film canvas (omitting `ratio` or using `"adaptive"` where I2V follows the first frame), the subject starts in the **beginning pose** of the requested action rather than an already-finished state, and every moving part has clear space inside the frame.
4. **Reuse one visual style anchor and plan cut bridges**: carry one concise lighting, color-temperature, lens and texture description across all shots, changing only framing, pose and action per shot. Connect shots intentionally with continuation frames, motion cuts, clean hard cuts or native transitions.
5. **Cross-check frames side-by-side before delivery**: inspect the anchor still alongside each clip's start, mid and end frames to confirm shape, details, palette and cut continuity before polishing or exporting.

## Replacing existing shots

Apply this when a template adaptation, recreation or edit generates media to replace shots that already exist in the source film.

When the request names which shots to replace, check each shot against that description and replace only the shots that clearly match. A shot that only partly fits, such as a product, tag or packaging close-up showing only hands or sleeves when the request replaces people, stays outside the request: keep the original shot and fix old brand names, logos or text on it in place with native cover, crop or overlay layers. Offering and approving generated replacements for them follows the [media authorization](../../openmotion-media/SKILL.md#provider-preference-and-authorization).

Write each replacement's generation input from the original shot. Look at its frames first, then keep its setting and background, lighting, shot size and camera angle, number and placement of people, action, camera movement and duration, changing only what the user asked to change. A description of the new subject, such as "outdoor hardshell jackets", changes the subject, not the setting; move the shot to a new location only when the user asks. Match the shot's role and composition, not its exact pixels or a real person's identity. Compare the result with the original shot on these points before using it.

## Mixed-media recreation boundaries

Apply this when a reference video combines motion graphics with live-action footage, product photography, portraits, narration or music:

- **Faithfully rebuildable**: native editable typography, UI, charts, logos, captions and graphic transitions layered above generated or supplied visual plates and aligned sound, preserving the reference's story, framing, holds and hard cuts.
- **Approximate replacement only (state plainly, never overclaim)**:
  - **Identifiable real people and synced lip performance**: current generation routes do not clone a specific real person's likeness or voice, or produce frame-accurate lip-sync. Use a matching-vibe generated performer or user-supplied footage, and clearly tell the user when new narration plays over a speaking person whose mouth will not match.
  - **Unprovided physical product details or complex multi-object physics**: without clean supplied or official photos, generated pixels cannot guarantee exact logos, ports or inscriptions. Prefer supplied/official imagery first; otherwise disclose the approximation.
  - **Narration mixed inseparably with background music**: do not claim clean vocal removal when stems cannot be split; offer keeping the original mix, muting to build new narration plus music, or waiting for separate audio.
  - **Predominantly live-action footage with minimal editable structure**: tell the user directly that OpenMotion excels at mixed motion graphics, editable overlays/captions and targeted generated shots rather than regenerating an entire live-action film shot-for-shot.

## Recorded speech, transcript review and captions

For existing speech-led material, follow the [transcript workflow](../../../docs/transcripts.md) for source discovery, recognition, correction and editable captions through `openmotion_assets_use`; configure any needed transcription provider through [openmotion-media](../../openmotion-media/SKILL.md). When a film also needs newly generated TTS voiceover or script-led captions (and the screen does not already carry those lines as synchronized display typography), follow [narration and editable captions](sound.md#配音与可编辑字幕协同) to bind real timing and keep captions editable. Continue composition edits and delivery through the existing native workflow.
